<footer>
	<div class="footer-inner">
    	<div class="container text-center">
			<p><a href="#">About</a> | <a href="#">Terms & Conditions</a> | <a href="#">Privacy Policy</a> | <a href="#">Contact</a> </p>
			<div>&copy; {{ date('Y') }} - All Rights Reserved.</div>
        </div>
    </div>
</footer>